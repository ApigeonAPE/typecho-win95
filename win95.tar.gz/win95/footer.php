<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>


	<script src="<?php $this->options->themeUrl('assets/js/001.js'); ?>"></script>
	<script src="<?php $this->options->themeUrl('assets/js/002.js'); ?>"></script>
	<div class="footer">
		<p> By Typecho|站长 老阡陌|<a href='https://www.bloglqm.top/admin/'><button name= "admin" type = "submit">后台</button></a>
</p>            	
	</div>


<?php $this->footer(); ?>
</body>
<script type="text/javascript" src="<?php $this->options->siteUrl(); ?>commentTyping.js"></script>

</html>
